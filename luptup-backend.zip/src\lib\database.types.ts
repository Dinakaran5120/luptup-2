// Auto-generated types matching the Supabase schema.sql
// Re-generate with: npx supabase gen types typescript --project-id YOUR_ID

export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: ProfileInsert;
        Update: ProfileUpdate;
      };
    };
  };
}

export interface Profile {
  id: string;
  phone: string | null;
  email: string | null;

  // Basic info
  name: string | null;
  date_of_birth: string | null;
  bio: string | null;
  avatar_url: string | null;
  photos: string[];

  // Looking For
  looking_for: string[];
  orientation: string | null;
  min_age: number;
  max_age: number;
  body_type: string | null;

  // About You
  interests: string[];
  languages: string[];
  location_state: string | null;
  personality: string | null;
  relationship_status: string | null;
  relationship_intent: string | null;

  // Meta
  onboarding_done: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type ProfileInsert = Partial<Profile> & { id: string };
export type ProfileUpdate = Partial<Omit<Profile, "id" | "created_at">>;
