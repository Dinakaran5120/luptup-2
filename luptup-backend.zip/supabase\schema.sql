-- ============================================================
-- LUP TUP — Supabase Database Schema
-- Run this in your Supabase project: SQL Editor → New Query
-- ============================================================

-- ── 1. PROFILES ──────────────────────────────────────────────
create table if not exists public.profiles (
  id                  uuid        references auth.users on delete cascade primary key,
  phone               text,
  email               text,

  -- Basic info
  name                text,
  date_of_birth       date,
  bio                 text,
  avatar_url          text,
  photos              text[]      default '{}',

  -- Looking For (onboarding step 2)
  looking_for         text[]      default '{}',
  orientation         text,
  min_age             integer     default 18,
  max_age             integer     default 35,
  body_type           text,

  -- About You (onboarding step 3)
  interests           text[]      default '{}',
  languages           text[]      default '{}',
  location_state      text,
  personality         text,
  relationship_status text,
  relationship_intent text,

  -- Meta
  onboarding_done     boolean     default false,
  is_active           boolean     default true,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now()
);

-- ── 2. ROW LEVEL SECURITY ─────────────────────────────────────
alter table public.profiles enable row level security;

-- Own profile: full access
create policy "profile_select_own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profile_insert_own"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "profile_update_own"
  on public.profiles for update
  using (auth.uid() = id);

-- Other authenticated users can view active profiles (for discover/matching)
create policy "profile_select_others"
  on public.profiles for select
  using (auth.uid() != id and is_active = true and onboarding_done = true);

-- ── 3. AUTO-CREATE PROFILE ON SIGN UP ─────────────────────────
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, phone, email)
  values (
    new.id,
    new.raw_user_meta_data->>'phone',
    new.email
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ── 4. AUTO-UPDATE updated_at ─────────────────────────────────
create or replace function public.update_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.update_updated_at();

-- ── 5. STORAGE BUCKET FOR PROFILE PHOTOS ──────────────────────
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict do nothing;

create policy "avatar_upload_own"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "avatar_public_read"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "avatar_update_own"
  on storage.objects for update
  using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
