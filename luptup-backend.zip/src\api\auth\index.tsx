import { supabase } from "@/lib/supabase";
import { useMutation } from "@tanstack/react-query";

// ─── Phone OTP ────────────────────────────────────────────────────────────────

/** Send OTP to phone number (works for both new & existing users) */
export const useSignInWithOtp = () => {
  return useMutation({
    mutationFn: async (phone: string) => {
      const { error } = await supabase.auth.signInWithOtp({ phone });
      if (error) {
        let message = "Something went wrong, please try again later.";
        if (error.message.includes("rate")) message = "Too many attempts. Please try again later.";
        if (error.message.includes("invalid")) message = "Please ensure your phone number is correct.";
        throw new Error(message);
      }
    },
  });
};

/** Verify phone OTP — signs in or creates account automatically */
export const useVerifyOtp = () => {
  return useMutation({
    mutationFn: async ({ phone, token }: { phone: string; token: string }) => {
      const { error } = await supabase.auth.verifyOtp({
        phone,
        token,
        type: "sms",
      });
      if (error) {
        let message = "Something went wrong, please try again later.";
        if (error.message.includes("expired") || error.message.includes("invalid"))
          message = "Your code is either invalid or expired.";
        throw new Error(message);
      }
    },
  });
};

// ─── Email OTP (Magic Link / passwordless) ───────────────────────────────────

/** Send OTP / magic link to email (works for both new & existing users) */
export const useSignInWithEmailOtp = () => {
  return useMutation({
    mutationFn: async (email: string) => {
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: { shouldCreateUser: true },
      });
      if (error) {
        let message = "Something went wrong, please try again later.";
        if (error.message.includes("rate")) message = "Too many attempts. Please try again later.";
        if (error.message.includes("invalid")) message = "Please enter a valid email address.";
        throw new Error(message);
      }
    },
  });
};

/** Verify email OTP — signs in or creates account automatically */
export const useVerifyEmailOtp = () => {
  return useMutation({
    mutationFn: async ({ email, token }: { email: string; token: string }) => {
      const { error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: "email",
      });
      if (error) {
        let message = "Something went wrong, please try again later.";
        if (error.message.includes("expired") || error.message.includes("invalid"))
          message = "Your code is either invalid or expired.";
        throw new Error(message);
      }
    },
  });
};

// ─── Sign Out ─────────────────────────────────────────────────────────────────

export const useSignOut = () => {
  return useMutation({
    mutationFn: async () => {
      const { error } = await supabase.auth.signOut();
      if (error) throw new Error(error.message);
    },
  });
};
