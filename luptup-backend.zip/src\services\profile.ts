/**
 * Profile Service — all CRUD operations for the profiles table.
 * Used by onboarding (create/update), account page (read), settings (update/delete).
 */
import { supabase } from "@/lib/supabase";
import type { Profile, ProfileUpdate } from "@/lib/database.types";

// ─── GET ──────────────────────────────────────────────────────────────────────

/** Fetch the currently signed-in user's profile */
export async function getMyProfile(): Promise<Profile | null> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;

  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", session.user.id)
    .single();

  if (error) {
    console.error("getMyProfile error:", error.message);
    return null;
  }
  return data as Profile;
}

// ─── UPDATE ───────────────────────────────────────────────────────────────────

/** Partial update — only sends fields you pass in */
export async function updateProfile(fields: ProfileUpdate): Promise<Profile | null> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error("Not authenticated");

  const { data, error } = await supabase
    .from("profiles")
    .update(fields)
    .eq("id", session.user.id)
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as Profile;
}

// ─── ONBOARDING SAVE ─────────────────────────────────────────────────────────

export interface OnboardingData {
  // Step 2 — Looking For
  looking_for: string[];
  orientation: string | null;
  min_age: number;
  max_age: number;
  body_type: string | null;

  // Step 3 — About You
  interests: string[];
  languages: string[];
  location_state: string | null;
  personality: string | null;
  relationship_status: string | null;
  relationship_intent: string | null;

  // Step 4 — Create Profile
  name: string;
  bio: string;
  avatar_url?: string | null;
}

/** Called when the user taps "Let's go!" — saves all onboarding data at once */
export async function saveOnboardingProfile(data: OnboardingData): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error("Not authenticated");

  const { error } = await supabase
    .from("profiles")
    .update({
      ...data,
      onboarding_done: true,
    })
    .eq("id", session.user.id);

  if (error) throw new Error(error.message);
}

// ─── AVATAR UPLOAD ────────────────────────────────────────────────────────────

/**
 * Upload a profile photo to Supabase Storage.
 * Returns the public URL of the uploaded image.
 */
export async function uploadAvatar(localUri: string): Promise<string> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error("Not authenticated");

  const userId = session.user.id;
  const ext = localUri.split(".").pop() ?? "jpg";
  const path = `${userId}/avatar.${ext}`;

  // Convert URI to blob
  const response = await fetch(localUri);
  const blob = await response.blob();

  const { error: uploadError } = await supabase.storage
    .from("avatars")
    .upload(path, blob, { upsert: true, contentType: `image/${ext}` });

  if (uploadError) throw new Error(uploadError.message);

  const { data } = supabase.storage.from("avatars").getPublicUrl(path);
  return data.publicUrl;
}

// ─── DEACTIVATE ───────────────────────────────────────────────────────────────

export async function deactivateAccount(): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error("Not authenticated");

  const { error } = await supabase
    .from("profiles")
    .update({ is_active: false })
    .eq("id", session.user.id);

  if (error) throw new Error(error.message);
  await supabase.auth.signOut();
}
