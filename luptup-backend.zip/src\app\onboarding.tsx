/**
 * Onboarding flow — shown once after first sign-in.
 * Five steps: Welcome Slides → Terms & Conditions → Looking For → About You → Create Profile
 *
 * IMAGE FILES REQUIRED in assets/images/:
 *   slide-lesbian.jpg  — lesbian couple (blue hair) photo
 *   slide-gay.jpg      — gay couple (glasses) photo
 *   slide-sunset.jpg   — sunset couple silhouette photo
 */
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Svg, { Defs, LinearGradient as SvgGradient, Rect, Stop } from "react-native-svg";
import { Slider } from "@miblanchard/react-native-slider";
import { Logo } from "@/components/logo";
import { useTheme } from "@/context/theme";
import { useAppState } from "@/store/app-state";
import { saveOnboardingProfile, uploadAvatar } from "@/services/profile";
import * as ImagePicker from "expo-image-picker";

export const ONBOARDING_KEY = "luptup_onboarding_done";

const { width, height } = Dimensions.get("window");

// ─── Brand colors ─────────────────────────────────────────────────────────────
const PRIMARY = "#692ce3";
const BG = "#0d0d1a";
const CARD_BG = "rgba(255,255,255,0.06)";
const TEXT = "#ffffff";
const MUTED = "rgba(255,255,255,0.55)";
const BORDER = "rgba(255,255,255,0.12)";

// ─── Slide data (full-background photos) ─────────────────────────────────────
const SLIDES = [
  {
    headline: "Find someone",
    highlight: "who gets you",
    subtitle: "Lup Tup is a safe space for\nmeaningful connections.",
    image: require("../../assets/images/slide-lesbian.jpg"),
  },
  {
    headline: "Love in all",
    highlight: "its beautiful forms",
    subtitle: "We celebrate every kind of\nlove — you belong here.",
    image: require("../../assets/images/slide-gay.jpg"),
  },
  {
    headline: "Your perfect",
    highlight: "connection awaits",
    subtitle: "Thousands of real people are\nwaiting to connect with you.",
    image: require("../../assets/images/slide-sunset.jpg"),
  },
];

// ─── Terms content ────────────────────────────────────────────────────────────
const TERMS = [
  {
    title: "1. Acceptance of Terms",
    body: "By accessing or using Lup Tup, you agree to be bound by these Terms and Conditions.",
  },
  {
    title: "2. User Conduct",
    body: "You agree to use Lup Tup respectfully and lawfully. Harassment, spam, or any abusive behavior is not allowed.",
  },
  {
    title: "3. Privacy",
    body: "Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and protect your data.",
  },
  {
    title: "4. Content",
    body: "You are responsible for the content you share. We reserve the right to remove any content that violates our policies.",
  },
  {
    title: "5. Termination",
    body: "We may suspend or terminate your account if you violate these Terms.",
  },
];

// ─── Indian States list ────────────────────────────────────────────────────────
const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Delhi", "Jammu & Kashmir", "Ladakh", "Chandigarh", "Puducherry",
];

// ─── Shared Chip component ─────────────────────────────────────────────────────
function Chip({
  label,
  selected,
  onPress,
  disabled,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.75}
      onPress={onPress}
      style={{
        backgroundColor: selected ? PRIMARY : "rgba(255,255,255,0.06)",
        borderWidth: 1,
        borderColor: selected ? PRIMARY : BORDER,
        borderRadius: 20,
        paddingHorizontal: 16,
        paddingVertical: 8,
        margin: 4,
        opacity: disabled ? 0.5 : 1,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins-Medium",
          fontSize: 14,
          color: selected ? "#fff" : MUTED,
        }}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── Section header helper ─────────────────────────────────────────────────────
function SectionLabel({ label }: { label: string }) {
  return (
    <Text
      style={{
        fontFamily: "Poppins-SemiBold",
        fontSize: 15,
        color: TEXT,
        marginBottom: 10,
        marginTop: 28,
      }}
    >
      {label}
    </Text>
  );
}

// ─── Step 0 — Welcome Slides (full-background swipeable photos) ───────────────
function SlidesStep({ onNext }: { onNext: () => void }) {
  const [slide, setSlide] = useState(0);
  const scrollRef = useRef<ScrollView>(null);

  const goToSlide = (index: number) => {
    scrollRef.current?.scrollTo({ x: index * width, animated: true });
    setSlide(index);
  };

  const handleNext = () => {
    if (slide < SLIDES.length - 1) {
      goToSlide(slide + 1);
    } else {
      onNext();
    }
  };

  const current = SLIDES[slide];

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* ── Swipeable full-background photos ── */}
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        onMomentumScrollEnd={(e) => {
          const newSlide = Math.round(e.nativeEvent.contentOffset.x / width);
          setSlide(newSlide);
        }}
        style={StyleSheet.absoluteFillObject}
        contentContainerStyle={{ width: width * SLIDES.length }}
      >
        {SLIDES.map((s, i) => (
          <Image
            key={i}
            source={s.image}
            style={{ width, height: "100%" }}
            contentFit="cover"
          />
        ))}
      </ScrollView>

      {/* ── Top dark gradient ── */}
      <Svg
        style={{ position: "absolute", top: 0, left: 0, right: 0 }}
        width="100%"
        height={220}
      >
        <Defs>
          <SvgGradient id="topG" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor="#000" stopOpacity="0.72" />
            <Stop offset="100%" stopColor="#000" stopOpacity="0" />
          </SvgGradient>
        </Defs>
        <Rect width="100%" height={220} fill="url(#topG)" />
      </Svg>

      {/* ── Bottom dark gradient ── */}
      <Svg
        style={{ position: "absolute", bottom: 0, left: 0, right: 0 }}
        width="100%"
        height={420}
      >
        <Defs>
          <SvgGradient id="botG" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor="#0d0d1a" stopOpacity="0" />
            <Stop offset="45%" stopColor="#0d0d1a" stopOpacity="0.82" />
            <Stop offset="100%" stopColor="#0d0d1a" stopOpacity="1" />
          </SvgGradient>
        </Defs>
        <Rect width="100%" height={420} fill="url(#botG)" />
      </Svg>

      {/* ── UI overlay ── */}
      <SafeAreaView style={{ flex: 1 }}>
        {/* Top row: Logo + Skip */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingHorizontal: 24,
            paddingTop: 6,
          }}
        >
          <Logo variant="white" height={44} />
          <TouchableOpacity activeOpacity={0.7} onPress={onNext} style={{ padding: 8 }}>
            <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: PRIMARY }}>
              Skip
            </Text>
          </TouchableOpacity>
        </View>

        {/* Spacer */}
        <View style={{ flex: 1 }} />

        {/* Bottom text + dots + button */}
        <View style={{ paddingHorizontal: 28, paddingBottom: 36 }}>
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 32,
              color: TEXT,
              lineHeight: 38,
            }}
          >
            {current.headline}
          </Text>
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 32,
              color: PRIMARY,
              lineHeight: 38,
              marginBottom: 10,
            }}
          >
            {current.highlight}
          </Text>
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 14,
              color: "rgba(255,255,255,0.7)",
              lineHeight: 22,
              marginBottom: 28,
            }}
          >
            {current.subtitle}
          </Text>

          {/* Dots */}
          <View style={{ flexDirection: "row", justifyContent: "center", gap: 8, marginBottom: 28 }}>
            {SLIDES.map((_, i) => (
              <TouchableOpacity key={i} onPress={() => goToSlide(i)} activeOpacity={0.8}>
                <View
                  style={{
                    width: i === slide ? 24 : 8,
                    height: 8,
                    borderRadius: 4,
                    backgroundColor: i === slide ? PRIMARY : "rgba(255,255,255,0.3)",
                  }}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Next / Get Started button */}
          <TouchableOpacity
            activeOpacity={0.88}
            onPress={handleNext}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.55,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              {slide === SLIDES.length - 1 ? "Get Started" : "Next"}
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─── Step 1 — Terms & Conditions ─────────────────────────────────────────────
function TermsStep({ onBack, onNext }: { onBack: () => void; onNext: () => void }) {
  const [agreed, setAgreed] = useState(false);

  return (
    <View style={{ flex: 1, backgroundColor: BG }}>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
          <Text
            style={{
              flex: 1,
              fontFamily: "Poppins-SemiBold",
              fontSize: 18,
              color: TEXT,
              textAlign: "center",
            }}
          >
            Terms &amp; Conditions
          </Text>
          <View style={{ width: 26 }} />
        </View>

        {/* Scrollable terms */}
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
        >
          <View
            style={{
              backgroundColor: CARD_BG,
              borderRadius: 18,
              borderWidth: 1,
              borderColor: BORDER,
              padding: 20,
              gap: 20,
            }}
          >
            {TERMS.map((section, i) => (
              <View key={i}>
                <Text
                  style={{
                    fontFamily: "Poppins-SemiBold",
                    fontSize: 14,
                    color: TEXT,
                    marginBottom: 6,
                  }}
                >
                  {section.title}
                </Text>
                <Text
                  style={{
                    fontFamily: "Poppins-Light",
                    fontSize: 13,
                    color: MUTED,
                    lineHeight: 20,
                  }}
                >
                  {section.body}
                </Text>
                {i < TERMS.length - 1 && (
                  <View style={{ height: 1, backgroundColor: BORDER, marginTop: 20 }} />
                )}
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Footer: checkbox + button */}
        <View
          style={{
            paddingHorizontal: 20,
            paddingTop: 16,
            paddingBottom: Platform.OS === "ios" ? 24 : 20,
            borderTopWidth: 1,
            borderTopColor: BORDER,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setAgreed((v) => !v)}
            style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 }}
          >
            <View
              style={{
                width: 22,
                height: 22,
                borderRadius: 6,
                borderWidth: 2,
                borderColor: agreed ? PRIMARY : BORDER,
                backgroundColor: agreed ? PRIMARY : "transparent",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {agreed && <Ionicons name="checkmark" size={14} color="#fff" />}
            </View>
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 13,
                color: MUTED,
                flex: 1,
              }}
            >
              I agree to the{" "}
              <Text style={{ color: PRIMARY, fontFamily: "Poppins-Medium" }}>
                Terms &amp; Conditions
              </Text>
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={agreed ? 0.85 : 0.5}
            onPress={() => agreed && onNext()}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: agreed ? PRIMARY : "rgba(105,44,227,0.3)",
              alignItems: "center",
              justifyContent: "center",
              shadowColor: agreed ? PRIMARY : "transparent",
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: agreed ? 8 : 0,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              I Agree
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─── Step 2 — Looking For ─────────────────────────────────────────────────────
export interface LookingForData {
  looking_for: string[];
  orientation: string | null;
  min_age: number;
  max_age: number;
  body_type: string | null;
}

function LookingForStep({
  onBack,
  onNext,
}: {
  onBack: () => void;
  onNext: (data: LookingForData) => void;
}) {
  const [lookingFor, setLookingFor] = useState<string[]>([]);
  const [orientation, setOrientation] = useState<string | null>(null);
  const [maxAge, setMaxAge] = useState(35);
  const [bodyType, setBodyType] = useState<string | null>(null);

  const toggleLookingFor = (val: string) => {
    setLookingFor((prev) =>
      prev.includes(val) ? prev.filter((x) => x !== val) : [...prev, val]
    );
  };

  const toggleOrientation = (val: string) => {
    setOrientation((prev) => (prev === val ? null : val));
  };

  const toggleBodyType = (val: string) => {
    setBodyType((prev) => (prev === val ? null : val));
  };

  return (
    <View style={{ flex: 1, backgroundColor: BG }}>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
        >
          {/* Title */}
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 22,
              color: "#ffffff",
              marginBottom: 4,
            }}
          >
            Who are you looking for?
          </Text>
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 13,
              color: MUTED,
              marginBottom: 4,
            }}
          >
            Select all that apply
          </Text>

          {/* Section 1: Looking For */}
          <SectionLabel label="Looking For" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["Men", "Women", "Trans", "Prefer not to say"].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={lookingFor.includes(opt)}
                onPress={() => toggleLookingFor(opt)}
              />
            ))}
          </View>

          {/* Section 2: Sexual Orientation */}
          <SectionLabel label="Sexual Orientation" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {[
              "Straight", "Bisexual", "Gay", "Lesbian",
              "Queer", "Pansexual", "Asexual", "Prefer not to say",
            ].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={orientation === opt}
                onPress={() => toggleOrientation(opt)}
              />
            ))}
          </View>

          {/* Section 3: Age Range */}
          <SectionLabel label="Age Range" />
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 20,
              color: PRIMARY,
              marginBottom: 4,
            }}
          >
            18 - {maxAge}
          </Text>
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: MUTED,
              marginBottom: 12,
            }}
          >
            (minimum age is fixed at 18)
          </Text>
          <Slider
            value={[maxAge]}
            onValueChange={(v) => setMaxAge(Math.round(Array.isArray(v) ? v[0] : v))}
            minimumValue={18}
            maximumValue={100}
            step={1}
            minimumTrackTintColor={PRIMARY}
            maximumTrackTintColor={BORDER}
            thumbTintColor={PRIMARY}
          />
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: MUTED }}>18</Text>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: MUTED }}>100</Text>
          </View>

          {/* Section 4: Body Type */}
          <SectionLabel label="Body Type" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["Slim", "Athletic", "Average", "Curvy", "Chubby", "Prefer not to say"].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={bodyType === opt}
                onPress={() => toggleBodyType(opt)}
              />
            ))}
          </View>

          <View style={{ height: 24 }} />
        </ScrollView>

        {/* Continue button */}
        <View
          style={{
            paddingHorizontal: 24,
            paddingBottom: Platform.OS === "ios" ? 24 : 20,
            paddingTop: 12,
            borderTopWidth: 1,
            borderTopColor: BORDER,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() =>
              onNext({
                looking_for: lookingFor,
                orientation,
                min_age: 18,
                max_age: maxAge,
                body_type: bodyType,
              })
            }
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              Continue
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─── Step 3 — About You ───────────────────────────────────────────────────────
export interface AboutYouData {
  interests: string[];
  languages: string[];
  location_state: string | null;
  personality: string | null;
  relationship_status: string | null;
  relationship_intent: string | null;
}

function AboutYouStep({
  onBack,
  onNext,
}: {
  onBack: () => void;
  onNext: (data: AboutYouData) => void;
}) {
  const [interests, setInterests] = useState<string[]>([]);
  const [languages, setLanguages] = useState<string[]>([]);
  const [location, setLocation] = useState<string | null>(null);
  const [showStateModal, setShowStateModal] = useState(false);
  const [personality, setPersonality] = useState<string | null>(null);
  const [relationshipStatus, setRelationshipStatus] = useState<string | null>(null);
  const [relationshipIntent, setRelationshipIntent] = useState<string | null>(null);

  const INTERESTS = [
    "🌍 Travel", "🎬 Movies", "🎵 Music", "🎮 Games", "🍕 Food",
    "🐾 Pets", "💪 Fitness", "💄 Beauty", "📸 Modeling", "💃 Dancing",
  ];
  const MAX_INTERESTS = 5;

  const toggleInterest = (val: string) => {
    setInterests((prev) => {
      if (prev.includes(val)) return prev.filter((x) => x !== val);
      if (prev.length >= MAX_INTERESTS) return prev;
      return [...prev, val];
    });
  };

  const toggleLanguage = (val: string) => {
    setLanguages((prev) =>
      prev.includes(val) ? prev.filter((x) => x !== val) : [...prev, val]
    );
  };

  const togglePersonality = (val: string) => {
    setPersonality((prev) => (prev === val ? null : val));
  };

  const toggleRelStatus = (val: string) => {
    setRelationshipStatus((prev) => (prev === val ? null : val));
  };

  const toggleRelIntent = (val: string) => {
    setRelationshipIntent((prev) => (prev === val ? null : val));
  };

  return (
    <View style={{ flex: 1, backgroundColor: BG }}>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
        >
          {/* Title */}
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 22,
              color: "#ffffff",
              marginBottom: 4,
            }}
          >
            Tell us about you
          </Text>

          {/* Section 1: Interests */}
          <SectionLabel label="Interests" />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: MUTED,
              marginBottom: 10,
              marginTop: -6,
            }}
          >
            (select up to 5)
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {INTERESTS.map((opt) => {
              const isSelected = interests.includes(opt);
              const isDisabled = !isSelected && interests.length >= MAX_INTERESTS;
              return (
                <Chip
                  key={opt}
                  label={opt}
                  selected={isSelected}
                  onPress={() => !isDisabled && toggleInterest(opt)}
                  disabled={isDisabled}
                />
              );
            })}
          </View>

          {/* Section 2: Languages */}
          <SectionLabel label="Languages" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["English", "Hindi", "Tamil", "Telugu", "Malayalam", "Kannada", "Urdu"].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={languages.includes(opt)}
                onPress={() => toggleLanguage(opt)}
              />
            ))}
          </View>

          {/* Section 3: Location */}
          <SectionLabel label="Location" />
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setShowStateModal(true)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              backgroundColor: CARD_BG,
              borderWidth: 1,
              borderColor: BORDER,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 14,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 14,
                color: location ? TEXT : MUTED,
              }}
            >
              {location ?? "Select your state →"}
            </Text>
            <Ionicons name="chevron-forward" size={16} color={MUTED} />
          </TouchableOpacity>

          {/* Section 4: Personality */}
          <SectionLabel label="Personality" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["🧘 Introvert", "🎉 Extrovert", "⚖️ Ambivert"].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={personality === opt}
                onPress={() => togglePersonality(opt)}
              />
            ))}
          </View>

          {/* Section 5: Relationship Status */}
          <SectionLabel label="Relationship Status" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["Single", "Married", "Open Relationship", "Divorced"].map((opt) => (
              <Chip
                key={opt}
                label={opt}
                selected={relationshipStatus === opt}
                onPress={() => toggleRelStatus(opt)}
              />
            ))}
          </View>

          {/* Section 6: Relationship Intent */}
          <SectionLabel label="Relationship Intent" />
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginHorizontal: -4 }}>
            {["👥 Friend", "💍 Marriage", "❤️ Serious Relationship", "☕ Casual Dating"].map(
              (opt) => (
                <Chip
                  key={opt}
                  label={opt}
                  selected={relationshipIntent === opt}
                  onPress={() => toggleRelIntent(opt)}
                />
              )
            )}
          </View>

          <View style={{ height: 24 }} />
        </ScrollView>

        {/* Continue button */}
        <View
          style={{
            paddingHorizontal: 24,
            paddingBottom: Platform.OS === "ios" ? 24 : 20,
            paddingTop: 12,
            borderTopWidth: 1,
            borderTopColor: BORDER,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() =>
              onNext({
                interests,
                languages,
                location_state: location,
                personality,
                relationship_status: relationshipStatus,
                relationship_intent: relationshipIntent,
              })
            }
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              Continue
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* State Selection Modal */}
      <Modal
        visible={showStateModal}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setShowStateModal(false)}
      >
        <SafeAreaView style={{ flex: 1, backgroundColor: BG }}>
          {/* Modal header */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: BORDER,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins-SemiBold",
                fontSize: 18,
                color: TEXT,
              }}
            >
              Select State
            </Text>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => setShowStateModal(false)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: CARD_BG,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: TEXT }}>
                ×
              </Text>
            </TouchableOpacity>
          </View>

          <FlatList
            data={INDIAN_STATES}
            keyExtractor={(item) => item}
            renderItem={({ item }) => (
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => {
                  setLocation(item);
                  setShowStateModal(false);
                }}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  paddingHorizontal: 24,
                  paddingVertical: 16,
                  borderBottomWidth: 1,
                  borderBottomColor: BORDER,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Poppins-Regular",
                    fontSize: 15,
                    color: location === item ? PRIMARY : TEXT,
                  }}
                >
                  {item}
                </Text>
                {location === item && (
                  <Ionicons name="checkmark" size={18} color={PRIMARY} />
                )}
              </TouchableOpacity>
            )}
          />
        </SafeAreaView>
      </Modal>
    </View>
  );
}

// ─── Step 4 — Create Profile ──────────────────────────────────────────────────
function CreateProfileStep({
  onBack,
  lookingForData,
  aboutYouData,
}: {
  onBack: () => void;
  lookingForData: LookingForData;
  aboutYouData: AboutYouData;
}) {
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const MAX_BIO = 500;
  const { markOnboardingDone } = useAppState();

  const pickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow photo access to upload a profile picture.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setAvatarUri(result.assets[0].uri);
    }
  };

  const handleFinish = async () => {
    if (isSaving) return;
    setIsSaving(true);
    try {
      let avatar_url: string | null = null;
      if (avatarUri) {
        avatar_url = await uploadAvatar(avatarUri);
      }
      await saveOnboardingProfile({
        ...lookingForData,
        ...aboutYouData,
        name: name.trim() || "Lup Tup User",
        bio: bio.trim(),
        avatar_url,
      });
      await markOnboardingDone();
    } catch (err: any) {
      Alert.alert("Error", err.message ?? "Could not save profile. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: BG }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 14,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
          <View style={{ width: 26 }} />
        </View>

        <ScrollView
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 26,
              color: TEXT,
              textAlign: "center",
              marginBottom: 8,
            }}
          >
            Create your profile
          </Text>
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 13,
              color: MUTED,
              textAlign: "center",
              lineHeight: 20,
              marginBottom: 36,
            }}
          >
            Add photos and a bio to help others{"\n"}know the real you.
          </Text>

          {/* Photo upload circle */}
          <View style={{ alignItems: "center", marginBottom: 24 }}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={pickPhoto}
              style={{
                width: 150,
                height: 150,
                borderRadius: 75,
                borderWidth: 2.5,
                borderColor: PRIMARY,
                borderStyle: avatarUri ? "solid" : "dashed",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "rgba(105,44,227,0.08)",
                overflow: "hidden",
              }}
            >
              {avatarUri ? (
                <Image source={{ uri: avatarUri }} style={{ width: 150, height: 150 }} contentFit="cover" />
              ) : (
                <>
                  <Ionicons name="camera-outline" size={36} color={PRIMARY} />
                  <Text style={{ fontFamily: "Poppins-Medium", fontSize: 13, color: TEXT, marginTop: 6 }}>
                    Add photo
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>

          {/* Name */}
          <Text
            style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: TEXT, marginBottom: 10 }}
          >
            Your name
          </Text>
          <View
            style={{
              backgroundColor: CARD_BG,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: BORDER,
              paddingHorizontal: 16,
              paddingVertical: 12,
              marginBottom: 20,
            }}
          >
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="Enter your name"
              placeholderTextColor={MUTED}
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 15,
                color: TEXT,
              }}
            />
          </View>

          {/* About me */}
          <Text
            style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: TEXT, marginBottom: 12 }}
          >
            About me
          </Text>
          <View
            style={{
              backgroundColor: CARD_BG,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: BORDER,
              padding: 16,
              minHeight: 120,
            }}
          >
            <TextInput
              value={bio}
              onChangeText={(t) => setBio(t.slice(0, MAX_BIO))}
              placeholder="Write something about yourself..."
              placeholderTextColor={MUTED}
              multiline
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 14,
                color: TEXT,
                flex: 1,
                minHeight: 80,
                textAlignVertical: "top",
              }}
            />
            <Text
              style={{
                fontFamily: "Poppins-Light",
                fontSize: 11,
                color: MUTED,
                textAlign: "right",
                marginTop: 8,
              }}
            >
              {bio.length}/{MAX_BIO}
            </Text>
          </View>
          <View style={{ height: 32 }} />
        </ScrollView>

        {/* Let's go button */}
        <View
          style={{
            paddingHorizontal: 24,
            paddingBottom: Platform.OS === "ios" ? 24 : 20,
            paddingTop: 12,
            borderTopWidth: 1,
            borderTopColor: BORDER,
          }}
        >
          <TouchableOpacity
            activeOpacity={isSaving ? 1 : 0.85}
            onPress={handleFinish}
            disabled={isSaving}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: isSaving ? "rgba(105,44,227,0.6)" : PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "row",
              gap: 10,
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            {isSaving ? (
              <>
                <ActivityIndicator size="small" color="#fff" />
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
                  Saving...
                </Text>
              </>
            ) : (
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
                Let's go!
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

// ─── Root Onboarding Screen ───────────────────────────────────────────────────
type Step = "slides" | "terms" | "lookingFor" | "aboutYou" | "createProfile";

const DEFAULT_LOOKING_FOR: LookingForData = {
  looking_for: [],
  orientation: null,
  min_age: 18,
  max_age: 35,
  body_type: null,
};

const DEFAULT_ABOUT_YOU: AboutYouData = {
  interests: [],
  languages: [],
  location_state: null,
  personality: null,
  relationship_status: null,
  relationship_intent: null,
};

export default function OnboardingScreen() {
  const [step, setStep] = useState<Step>("slides");
  const [lookingForData, setLookingForData] = useState<LookingForData>(DEFAULT_LOOKING_FOR);
  const [aboutYouData, setAboutYouData] = useState<AboutYouData>(DEFAULT_ABOUT_YOU);

  if (step === "slides") {
    return <SlidesStep onNext={() => setStep("terms")} />;
  }
  if (step === "terms") {
    return (
      <TermsStep
        onBack={() => setStep("slides")}
        onNext={() => setStep("lookingFor")}
      />
    );
  }
  if (step === "lookingFor") {
    return (
      <LookingForStep
        onBack={() => setStep("terms")}
        onNext={(data) => {
          setLookingForData(data);
          setStep("aboutYou");
        }}
      />
    );
  }
  if (step === "aboutYou") {
    return (
      <AboutYouStep
        onBack={() => setStep("lookingFor")}
        onNext={(data) => {
          setAboutYouData(data);
          setStep("createProfile");
        }}
      />
    );
  }
  return (
    <CreateProfileStep
      onBack={() => setStep("aboutYou")}
      lookingForData={lookingForData}
      aboutYouData={aboutYouData}
    />
  );
}
