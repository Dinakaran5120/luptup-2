/**
 * Global app state — tracks onboarding completion.
 *
 * Priority order for onboarding_done:
 *  1. DB (profiles.onboarding_done) — source of truth for returning users
 *  2. AsyncStorage — local fallback / instant read on mount
 *
 * This means a user who completed onboarding on another device
 * will skip it automatically on login.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export const ONBOARDING_KEY = "luptup_onboarding_done";

interface AppStateContextType {
  onboardingDone: boolean | null; // null = still resolving
  markOnboardingDone: () => Promise<void>;
}

const AppStateContext = createContext<AppStateContextType>({
  onboardingDone: null,
  markOnboardingDone: async () => {},
});

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;

    const resolve = async () => {
      // 1. Fast local check first (instant)
      const local = await AsyncStorage.getItem(ONBOARDING_KEY);
      if (!cancelled && local) {
        setOnboardingDone(true);
        return;
      }

      // 2. Check DB for returning users on new devices
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
          const { data } = await supabase
            .from("profiles")
            .select("onboarding_done")
            .eq("id", session.user.id)
            .single();

          if (!cancelled) {
            const done = data?.onboarding_done ?? false;
            if (done) {
              // Sync locally so next launch is instant
              await AsyncStorage.setItem(ONBOARDING_KEY, "true");
            }
            setOnboardingDone(done);
            return;
          }
        }
      } catch {
        // No network or DB error — fall through to false
      }

      if (!cancelled) setOnboardingDone(!!local);
    };

    resolve();
    return () => { cancelled = true; };
  }, []);

  const markOnboardingDone = async () => {
    // Immediate state update so NavigationGuard reacts in this render cycle
    setOnboardingDone(true);
    // Persist locally
    await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    // DB is already updated by saveOnboardingProfile() in onboarding.tsx
  };

  return (
    <AppStateContext.Provider value={{ onboardingDone, markOnboardingDone }}>
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => useContext(AppStateContext);
